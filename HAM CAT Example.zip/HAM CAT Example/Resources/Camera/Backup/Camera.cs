using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using DirectShowLib;
using DirectShowLib.Utils;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.IO;
using System.Reflection;
using System.Collections;


namespace Camera
{
    public partial class Camera : Form
    {
        public Camera()
        {
            InitializeComponent();
        }

        IBaseFilter videoFilter = null;
        IBaseFilter audioFilter = null;
        IBaseFilter audioCodecFilter = null;
        IBaseFilter videoCodecFilter = null;


        IBaseFilter mux = null;
        IFileSinkFilter sink = null;

        IVideoWindow videoWindow = null;
        IMediaControl mediaControl = null;
        IMediaEventEx mediaEventEx = null;
        IGraphBuilder graphBuilder = null;
        ICaptureGraphBuilder2 captureGraphBuilder = null;
        IAMTVTuner tuner = null;
        IBaseFilter crossbar = null;
        SourceCollection videoSources = null;
        SourceCollection audioSources = null;

        DsROTEntry rot = null;
        bool previewing = false;
        bool recording = false;
        long timestart;
        string FileName = "D:\\Test.avi";


        public struct configuration
        {
            public string videoDevice;
            public string videoCodec;
            public string videoSize;
            public string videoFrameRate;
            public string videoCrossbarInput;
            public string videoTunerType; //antena//cable;
            public string videoChannel;

            public string audioDevice;
            public string audioInputSource;
            public string audioCodec;
            public string audioChanels;
            public string audioSamplingRate;
            public string audioSamplingSize;
            public string audioCapture;

        }


        configuration cfg;

        public void LoadCfg(string filename)
        {
            if (File.Exists(filename))
            {
                string text = File.ReadAllText(filename);
                StringReader sr = new StringReader(text);
                string wiersz = "";
                try
                {
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.videoDevice = wiersz; else cfg.videoDevice = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.videoCodec = wiersz; else cfg.videoCodec = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.videoSize = wiersz; else cfg.videoSize = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.videoFrameRate = wiersz; else cfg.videoFrameRate = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.videoCrossbarInput = wiersz; else cfg.videoCrossbarInput = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.videoTunerType = wiersz; else cfg.videoTunerType = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.videoChannel = wiersz; else cfg.videoChannel = null;

                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.audioDevice = wiersz; else cfg.audioDevice = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.audioInputSource = wiersz; else cfg.videoChannel = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.audioCodec = wiersz; else cfg.audioCodec = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.audioChanels = wiersz; else cfg.audioChanels = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.audioSamplingRate = wiersz; else cfg.audioSamplingRate = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.audioSamplingSize = wiersz; else cfg.audioSamplingSize = null;
                    wiersz = sr.ReadLine(); if (wiersz != null) cfg.audioCapture = wiersz; else cfg.audioCapture = null;

                }
                catch { }
            }

        }

        public void SaveCfg(string filename)
        {

            try
            {
                if (File.Exists(filename)) File.Delete(filename);
                StringWriter sw = new StringWriter();

                sw.WriteLine(cfg.videoDevice);
                sw.WriteLine(cfg.videoCodec);
                sw.WriteLine(cfg.videoSize);
                sw.WriteLine(cfg.videoFrameRate);
                sw.WriteLine(cfg.videoCrossbarInput);
                sw.WriteLine(cfg.videoTunerType);
                sw.WriteLine(cfg.videoChannel);

                sw.WriteLine(cfg.audioDevice);
                sw.WriteLine(cfg.audioInputSource);
                sw.WriteLine(cfg.audioCodec);
                sw.WriteLine(cfg.audioChanels);
                sw.WriteLine(cfg.audioSamplingRate);
                sw.WriteLine(cfg.audioSamplingSize);
                sw.WriteLine(cfg.audioCapture);

                File.WriteAllText(filename, sw.GetStringBuilder().ToString());
                sw.Dispose();
            }
            catch
            {

            }
        }

        public static string addSlash(string what)
        {
            if (what == "") return what;
            if (what[what.Length - 1] != '\\') return what + '\\'; else return what;
        }

        public string path
        {
            get
            {
                return addSlash(Path.GetDirectoryName(Application.ExecutablePath));
            }
        }

        public void SAVE()
        {
            SaveCfg(path + "config.cfg");
        }

        public void LOAD()
        {
            LoadCfg(path + "config.cfg");
        }




        public void CloseInterfaces()
        {
            // Stop previewing data
            //  if (this.mediaControl != null)
            //   this.mediaControl.StopWhenReady();

            if (this.videoWindow != null)
            {
                this.videoWindow.put_Visible(OABool.False);
                this.videoWindow.put_Owner(IntPtr.Zero);
            }

            // Remove filter graph from the running object table
            if (rot != null)
            {
                rot.Dispose();
                rot = null;
            }

            // Release DirectShow interfaces
            if (this.mediaControl != null) Marshal.ReleaseComObject(this.mediaControl); this.mediaControl = null;
            if (this.mediaEventEx != null) Marshal.ReleaseComObject(this.mediaEventEx); this.mediaEventEx = null;
            if (this.videoWindow != null) Marshal.ReleaseComObject(this.videoWindow); this.videoWindow = null;
            if (this.graphBuilder != null) Marshal.ReleaseComObject(this.graphBuilder); this.graphBuilder = null;
            if (this.captureGraphBuilder != null) Marshal.ReleaseComObject(this.captureGraphBuilder); this.captureGraphBuilder = null;
            if (this.videoFilter != null) Marshal.ReleaseComObject(this.videoFilter); this.videoFilter = null;
            if (this.audioFilter != null) Marshal.ReleaseComObject(this.audioFilter); this.audioFilter = null;

            if (this.mux != null) Marshal.ReleaseComObject(mux); mux = null;
            if (this.sink != null) Marshal.ReleaseComObject(sink); sink = null;
            if (this.tuner != null) Marshal.ReleaseComObject(tuner); tuner = null;
            if (this.crossbar != null) Marshal.ReleaseComObject(crossbar); crossbar = null;
            if (videoSources != null) { videoSources.Clear(); videoSources.Dispose(); videoSources = null; }
            if (audioSources != null) { audioSources.Clear(); audioSources.Dispose(); audioSources = null; }
            // Marshal.ReleaseComObject(captureGraphBuilder);
        }

        /// <summary>
        /// Gets list of a Video Input devices 
        /// </summary>
        public void GetVidDevices()
        {
            VideoDevicesBox.Items.Clear();
            DsDevice[] devices;
            // Get all video input devices
            devices = DsDevice.GetDevicesOfCat(FilterCategory.VideoInputDevice);
            VideoDevicesBox.Items.Add("<None>");
            for (int i = 0; i < devices.Length; i++)
            {
                if (devices[i].Name != null) VideoDevicesBox.Items.Add(devices[i].Name);
            }
            VideoDevicesBox.SelectedIndex = 0;

        }


        public void GetVidCodecs()
        {
            VideoCodecsBox.Items.Clear();
            DsDevice[] devices;
            // Get all video input devices
            devices = DsDevice.GetDevicesOfCat(FilterCategory.VideoCompressorCategory);
            VideoCodecsBox.Items.Add("<None>");
            for (int i = 0; i < devices.Length; i++)
            {
                if (devices[i].Name != null) VideoCodecsBox.Items.Add(devices[i].Name);
            }
            VideoCodecsBox.SelectedIndex = 0;

        }



        public void GetAudDevices()
        {
            AudioDevicesBox.Items.Clear();
            DsDevice[] devices;
            // Get all video input devices
            devices = DsDevice.GetDevicesOfCat(FilterCategory.AudioInputDevice);
            AudioDevicesBox.Items.Add("<None>");
            for (int i = 0; i < devices.Length; i++)
            {
                if (devices[i].Name != null) AudioDevicesBox.Items.Add(devices[i].Name);
            }
            AudioDevicesBox.SelectedIndex = 0;
        }


        public void GetAudCodecs()
        {
            AudioCodecBox.Items.Clear();
            DsDevice[] devices;
            // Get all video input devices
            devices = DsDevice.GetDevicesOfCat(FilterCategory.AudioCompressorCategory);
            AudioCodecBox.Items.Add("<None>");
            for (int i = 0; i < devices.Length; i++)
            {
                if (devices[i].Name != null) AudioCodecBox.Items.Add(devices[i].Name);
            }
            AudioCodecBox.SelectedIndex = 0;
        }


        public IBaseFilter FindCaptureDevice(int idx)
        {
            try
            {
                idx--;

                DsDevice[] devices;
                object source;

                // Get all video input devices
                devices = DsDevice.GetDevicesOfCat(FilterCategory.VideoInputDevice);
                if (idx >= 0 && idx < devices.Length)
                {
                    DsDevice device = devices[idx];

                    Guid iid = typeof(IBaseFilter).GUID;
                    device.Mon.BindToObject(null, null, ref iid, out source);

                    try
                    {
                        VideoDevicesBox.SelectedIndex = idx + 1;
                    }
                    catch { VideoDevicesBox.SelectedIndex = VideoDevicesBox.Items.Count; }
                    return (IBaseFilter)source;
                }
                else return null;
            }
            catch { return null; }
        }

        public IBaseFilter FindAudioDevice(int idx)
        {
            try
            {
                idx--;

                DsDevice[] devices;
                object source;

                // Get all video input devices
                devices = DsDevice.GetDevicesOfCat(FilterCategory.AudioInputDevice);
                if (idx >= 0 && idx < devices.Length)
                {
                    DsDevice device = devices[idx];

                    Guid iid = typeof(IBaseFilter).GUID;
                    device.Mon.BindToObject(null, null, ref iid, out source);

                    try
                    {
                        VideoDevicesBox.SelectedIndex = idx + 1;
                    }
                    catch { VideoDevicesBox.SelectedIndex = VideoDevicesBox.Items.Count - 1; }
                    return (IBaseFilter)source;
                }
                else return null;
            }
            catch { return null; }
        }

        public IBaseFilter FindVideoCompresor(int idx)
        {
            try
            {
                idx--;

                DsDevice[] devices;
                object source;

                // Get all video input devices
                devices = DsDevice.GetDevicesOfCat(FilterCategory.VideoCompressorCategory);
                if (idx >= 0 && idx < devices.Length)
                {
                    DsDevice device = devices[idx];

                    Guid iid = typeof(IBaseFilter).GUID;
                    device.Mon.BindToObject(null, null, ref iid, out source);

                    // VideoDevicesBox.SelectedIndex = idx + 1;
                    return (IBaseFilter)source;
                }
                else return null;
            }
            catch { return null; }
        }

        public IBaseFilter FindAudioCompresor(int idx)
        {
            try
            {
                idx--;

                DsDevice[] devices;
                object source;

                // Get all video input devices
                devices = DsDevice.GetDevicesOfCat(FilterCategory.AudioCompressorCategory);
                if (idx >= 0 && idx < devices.Length)
                {
                    DsDevice device = devices[idx];

                    Guid iid = typeof(IBaseFilter).GUID;
                    device.Mon.BindToObject(null, null, ref iid, out source);

                    // VideoDevicesBox.SelectedIndex = idx + 1;
                    return (IBaseFilter)source;
                }
                else return null;
            }
            catch { return null; }
        }


        public IBaseFilter FindCaptureDevice(string idx)
        {
            try
            {

                DsDevice[] devices;
                object source;

                // Get all video input devices
                devices = DsDevice.GetDevicesOfCat(FilterCategory.VideoInputDevice);
                for (int i = 0; i < devices.Length; i++)
                {
                    if (devices[i].Name == idx)
                    {
                        DsDevice device = devices[i];


                        Guid iid = typeof(IBaseFilter).GUID;
                        device.Mon.BindToObject(null, null, ref iid, out source);


                        return (IBaseFilter)source;
                    }
                }
                return null;
            }
            catch { return null; }
        }

        public IBaseFilter FindAudioDevice(string idx)
        {
            try
            {
                DsDevice[] devices;
                object source;

                // Get all video input devices
                devices = DsDevice.GetDevicesOfCat(FilterCategory.AudioInputDevice);
                for (int i = 0; i < devices.Length; i++)
                {
                    if (devices[i].Name == idx)
                    {
                        DsDevice device = devices[i];


                        Guid iid = typeof(IBaseFilter).GUID;
                        device.Mon.BindToObject(null, null, ref iid, out source);


                        return (IBaseFilter)source;
                    }
                }
                return null;
            }
            catch { return null; }
        }

        public IBaseFilter FindVideoCompresor(string idx)
        {
            try
            {

                DsDevice[] devices;
                object source;

                // Get all video input devices
                devices = DsDevice.GetDevicesOfCat(FilterCategory.VideoCompressorCategory);
                for (int i = 0; i < devices.Length; i++)
                {
                    if (devices[i].Name == idx)
                    {
                        DsDevice device = devices[i];


                        Guid iid = typeof(IBaseFilter).GUID;
                        device.Mon.BindToObject(null, null, ref iid, out source);


                        return (IBaseFilter)source;
                    }
                }
                return null;
            }
            catch { return null; }
        }

        public IBaseFilter FindAudioCompresor(string idx)
        {
            try
            {

                DsDevice[] devices;
                object source;

                // Get all video input devices
                devices = DsDevice.GetDevicesOfCat(FilterCategory.AudioCompressorCategory);
                for (int i = 0; i < devices.Length; i++)
                {
                    if (devices[i].Name == idx)
                    {
                        DsDevice device = devices[i];


                        Guid iid = typeof(IBaseFilter).GUID;
                        device.Mon.BindToObject(null, null, ref iid, out source);


                        return (IBaseFilter)source;
                    }
                }
                return null;
            }
            catch { return null; }
        }




        public void SetupVideoWindow()
        {
            try
            {
                int hr = 0;

                hr = this.videoWindow.put_Owner(panelVideo.Handle);
                DsError.ThrowExceptionForHR(hr);

                hr = this.videoWindow.put_WindowStyle(WindowStyle.Child | WindowStyle.ClipChildren | WindowStyle.ClipSiblings);
                DsError.ThrowExceptionForHR(hr);

                ResizeVideoWindow();
                hr = this.videoWindow.put_Visible(OABool.True);
                DsError.ThrowExceptionForHR(hr);
                videoWindow.put_MessageDrain(panelVideo.Handle);
            }
            catch { }
        }

        public void ResizeVideoWindow()
        {
            // Resize the video preview window to match owner window size
            if (this.videoWindow != null)
            {
                this.videoWindow.SetWindowPosition(0, 0, panelVideo.Width, panelVideo.Height);
            }
        }

        public SourceCollection VideoSources_
        {
            get
            {
                if (videoSources == null)
                {
                    try
                    {
                        if (videoFilter != null)
                            videoSources = new SourceCollection(captureGraphBuilder, videoFilter, true);
                        else
                            videoSources = new SourceCollection();
                    }
                    catch (Exception ex) { Debug.WriteLine("VideoSources: unable to create VideoSources." + ex.ToString()); }
                }
                return (videoSources);
            }
        }

        public SourceCollection AudioSources_
        {
            get
            {
                if (audioSources == null)
                {
                    try
                    {
                        if (audioFilter != null)
                            audioSources = new SourceCollection(captureGraphBuilder, audioFilter, false);
                        else
                            audioSources = new SourceCollection();
                    }
                    catch (Exception ex) { Debug.WriteLine("AudioSources: unable to create AudioSources." + ex.ToString()); }
                }
                return (audioSources);
            }
        }




        private void GetVidSources()
        {
            int hr;
            Crossbar.Visible = false;
            Tuner_.Visible = false;
            if (videoFilter != null)
            {
                hr = graphBuilder.AddFilter(videoFilter, "Video Capture Device");
                DsError.ThrowExceptionForHR(hr);


            }
            if (VideoSources_.Count > 0)
            {



                tuner = null;
                crossbar = null;
                object o;
                hr = captureGraphBuilder.FindInterface(null, null, videoFilter, typeof(IAMTVTuner).GUID, out o);
                if (hr >= 0)
                {
                    tuner = (IAMTVTuner)o;
                    o = null;

                    hr = captureGraphBuilder.FindInterface(null, null, videoFilter, typeof(IAMCrossbar).GUID, out o);
                    if (hr >= 0)
                    {
                        crossbar = (IBaseFilter)o;
                        o = null;
                    }
                    if (crossbar != null) Crossbar.Visible = true; else Crossbar.Visible = false;
                    if (tuner != null) Tuner_.Visible = true; else Tuner_.Visible = false;

                }


            }


        }

        private void GetAudioSources()
        {
            int hr;
            if (audioFilter != null)
            {
                AudioSourceBox.Items.Clear();
                hr = graphBuilder.AddFilter(audioFilter, "Audio Capture Device");
                if (hr == 0)
                {
                    Source s;
                    for (int c = 0; c < AudioSources_.Count; c++)
                    {
                        s = audioSources[c];

                        AudioSourceBox.Items.Add(s.Name);
                    }

                }
            }
        }


        private void GetSources(object sender, EventArgs e)
        {

            string vd = "";
            if (VideoDevicesBox.SelectedIndex > 0) vd = VideoDevicesBox.Items[VideoDevicesBox.SelectedIndex].ToString();

            string ad = "";
            if (AudioDevicesBox.SelectedIndex > 0) ad = AudioDevicesBox.Items[AudioDevicesBox.SelectedIndex].ToString();

            CloseInterfaces();

            graphBuilder = (IGraphBuilder)new FilterGraph();
            rot = new DsROTEntry(graphBuilder);
            captureGraphBuilder = (ICaptureGraphBuilder2)new CaptureGraphBuilder2();
            captureGraphBuilder.SetFiltergraph(graphBuilder);


            videoFilter = FindCaptureDevice(vd);
            audioFilter = FindAudioDevice(ad);

            if (graphBuilder != null && captureGraphBuilder != null)
            {
                GetVidSources();
                GetAudioSources();
            }
            // CloseInterfaces();


        }


        protected object setStreamConfigSetting(IAMStreamConfig streamConfig, string fieldName, object newValue)
        {
            try
            {
                if (streamConfig == null)
                    throw new NotSupportedException();
                //   assertStopped();
                // derenderGraph();

                object returnValue = null;
                IntPtr pmt = IntPtr.Zero;
                AMMediaType mediaType = new AMMediaType();

                try
                {
                    // Get the current format info
                    int hr = streamConfig.GetFormat(out mediaType);
                    if (hr != 0)
                        Marshal.ThrowExceptionForHR(hr);
                    //  Marshal.PtrToStructure(pmt, mediaType);

                    // The formatPtr member points to different structures
                    // dependingon the formatType
                    object formatStruct;
                    if (mediaType.formatType == FormatType.WaveEx)
                        formatStruct = new WaveFormatEx();
                    else if (mediaType.formatType == FormatType.VideoInfo)
                        formatStruct = new VideoInfoHeader();
                    else if (mediaType.formatType == FormatType.VideoInfo2)
                        formatStruct = new VideoInfoHeader2();
                    else
                        throw new NotSupportedException("This device does not support a recognized format block.");

                    // Retrieve the nested structure
                    Marshal.PtrToStructure(mediaType.formatPtr, formatStruct);

                    // Find the required field
                    Type structType = formatStruct.GetType();

                    FieldInfo fieldInfo = structType.GetField(fieldName);
                    if (fieldInfo == null)
                        throw new NotSupportedException("Unable to find the member '" + fieldName + "' in the format block.");

                    // Update the value of the field
                    fieldInfo.SetValue(formatStruct, newValue);

                    // PtrToStructure copies the data so we need to copy it back
                    Marshal.StructureToPtr(formatStruct, mediaType.formatPtr, false);

                    // Save the changes
                    hr = streamConfig.SetFormat(mediaType);
                    if (hr != 0)
                        Marshal.ThrowExceptionForHR(hr);
                }
                finally
                {
                    DsUtils.FreeAMMediaType(mediaType);
                    Marshal.FreeCoTaskMem(pmt);
                }
                return (returnValue);
            }
            catch { return null; }
        }


        protected object getStreamConfigSetting(IAMStreamConfig streamConfig, string fieldName)
        {
            try
            {
                if (streamConfig == null)
                    throw new NotSupportedException();
                //    assertStopped();
                //   derenderGraph();

                object returnValue = null;
                IntPtr pmt = IntPtr.Zero;
                AMMediaType mediaType = new AMMediaType();

                try
                {
                    // Get the current format info
                    int hr = streamConfig.GetFormat(out mediaType);
                    if (hr != 0)
                        Marshal.ThrowExceptionForHR(hr);
                    //  Marshal.PtrToStructure(pmt, mediaType);

                    // The formatPtr member points to different structures
                    // dependingon the formatType
                    object formatStruct;
                    if (mediaType.formatType == FormatType.WaveEx)
                        formatStruct = new WaveFormatEx();
                    else if (mediaType.formatType == FormatType.VideoInfo)
                        formatStruct = new VideoInfoHeader();
                    else if (mediaType.formatType == FormatType.VideoInfo2)
                        formatStruct = new VideoInfoHeader2();
                    else
                        throw new NotSupportedException("This device does not support a recognized format block.");

                    // Retrieve the nested structure
                    Marshal.PtrToStructure(mediaType.formatPtr, formatStruct);

                    // Find the required field
                    Type structType = formatStruct.GetType();
                    FieldInfo fieldInfo = structType.GetField(fieldName);
                    if (fieldInfo == null)
                        throw new NotSupportedException("Unable to find the member '" + fieldName + "' in the format block.");

                    // Extract the field's current value
                    returnValue = fieldInfo.GetValue(formatStruct);

                }
                finally
                {
                    DsUtils.FreeAMMediaType(mediaType);
                    Marshal.FreeCoTaskMem(pmt);
                }
                // renderGraph();
                // startPreviewIfNeeded();

                return (returnValue);
            }
            catch { return null; }
        }



        private void SetPinParameters(bool isPreview)
        {
            int hr = 0;
            object o;
            GC.Collect();

            graphBuilder = (IGraphBuilder)new FilterGraph();
            rot = new DsROTEntry(graphBuilder);
            captureGraphBuilder = (ICaptureGraphBuilder2)new CaptureGraphBuilder2();
            captureGraphBuilder.SetFiltergraph(graphBuilder);
            mediaControl = (IMediaControl)this.graphBuilder;
            videoWindow = (IVideoWindow)this.graphBuilder;
            videoFilter = FindCaptureDevice(cfg.videoDevice);
            videoCodecFilter = FindVideoCompresor(cfg.videoCodec);
            audioFilter = FindAudioDevice(cfg.audioDevice);
            audioCodecFilter = FindAudioCompresor(cfg.audioCodec);
            bool audio = (cfg.audioCapture.ToLower()[0] == 't');

            if (videoFilter != null)
            {
                //Add the Video input device to the graph
                hr = graphBuilder.AddFilter(videoFilter, "Video Capture Device");
                DsError.ThrowExceptionForHR(hr);


                if (!isPreview)
                {
                    if (audioFilter != null)
                    {
                        hr = graphBuilder.AddFilter(audioFilter, "Audio Capture Device");
                        DsError.ThrowExceptionForHR(hr);
                    }

                    if (videoCodecFilter != null)
                    {
                        hr = graphBuilder.AddFilter(videoCodecFilter, "Video Compressor");
                        DsError.ThrowExceptionForHR(hr);
                    }

                    if (audioCodecFilter != null && audio)
                    {

                        hr = graphBuilder.AddFilter(audioCodecFilter, "Audio Compressor");
                        DsError.ThrowExceptionForHR(hr);
                    }
                }

                string SvideoFrameRate = cfg.videoFrameRate;
                string SaudioSamplingRate = cfg.audioSamplingRate;
                string SaudioSamplingSize = cfg.audioSamplingSize;



                if (SvideoFrameRate.IndexOf(' ') > 0) SvideoFrameRate = SvideoFrameRate.Remove(SvideoFrameRate.IndexOf(' ') - 1);
                if (SaudioSamplingRate.IndexOf(' ') > 0) SaudioSamplingRate = SaudioSamplingRate.Remove(SaudioSamplingRate.IndexOf(' ') - 1);
                if (SaudioSamplingSize.IndexOf(' ') > 0) SaudioSamplingSize = SaudioSamplingSize.Remove(SaudioSamplingSize.IndexOf(' ') - 1);
                int videoFrameRate, audioSamplingRate;
                short audioSamplingSize;

                int.TryParse(SvideoFrameRate, out videoFrameRate); if (videoFrameRate < 1) videoFrameRate = 25;
                int.TryParse(SaudioSamplingRate, out audioSamplingRate); if (audioSamplingRate < 8000) audioSamplingRate = 8000;
                short.TryParse(SaudioSamplingSize, out audioSamplingSize); if (audioSamplingSize < 8) audioSamplingSize = 16;
                short nchannels = 2;
                if (cfg.audioChanels.ToLower()[0] == 's') nchannels = 2; else nchannels = 1;
                Size size = getVidSize(cfg.videoSize);
                if (size.Width < 1 || size.Height < 1) { size.Width = 320; size.Height = 240; }


                if (isPreview)
                    hr = captureGraphBuilder.FindInterface(PinCategory.Preview, MediaType.Video, videoFilter, typeof(IAMStreamConfig).GUID, out o);
                else
                    hr = captureGraphBuilder.FindInterface(PinCategory.Capture, MediaType.Video, videoFilter, typeof(IAMStreamConfig).GUID, out o);
                if (hr > 0)
                {
                    IAMStreamConfig videoStreamConfig = (IAMStreamConfig)o;
                    long avgTimePerFrame = (long)(10000000 / videoFrameRate);  // klatki na s
                    setStreamConfigSetting(videoStreamConfig, "AvgTimePerFrame", avgTimePerFrame);
                    BitmapInfoHeader bmiHeader;  // rozmiar klatki
                    bmiHeader = (BitmapInfoHeader)getStreamConfigSetting(videoStreamConfig, "BmiHeader");


                    bmiHeader.Width = size.Width;
                    bmiHeader.Height = size.Height;
                    setStreamConfigSetting(videoStreamConfig, "BmiHeader", bmiHeader);
                }

                tuner = null;
                crossbar = null;

                hr = captureGraphBuilder.FindInterface(null, null, videoFilter, typeof(IAMTVTuner).GUID, out o);
                if (hr >= 0)
                {
                    tuner = (IAMTVTuner)o;
                    o = null;

                    hr = captureGraphBuilder.FindInterface(null, null, videoFilter, typeof(IAMCrossbar).GUID, out o);
                    if (hr >= 0)
                    {
                        crossbar = (IBaseFilter)o;
                        o = null;
                    }
                }

                if (tuner != null)
                {
                    int channel;
                    int.TryParse(cfg.videoChannel, out channel);
                    AMTunerSubChannel videoSubCh, audioSubCh;
                    videoSubCh = AMTunerSubChannel.Default; audioSubCh = AMTunerSubChannel.Default;
                    tuner.put_Channel(channel, videoSubCh, audioSubCh);
                    // cfg.videoChannel = channel.ToString();
                }

                if (crossbar != null)
                {
                    if (VideoSources_.Count > 0)
                    {
                        for (int i = 0; i < videoSources.Count; i++)
                        {
                            if (videoSources[i].Name == cfg.videoCrossbarInput) videoSources[i].Enabled = true;
                        }
                    }

                }



                if (audioFilter != null && audio)
                {
                    if (isPreview)
                    {
                        hr = captureGraphBuilder.FindInterface(PinCategory.Preview, MediaType.Audio, audioFilter, typeof(IAMStreamConfig).GUID, out o);
                    }
                    else
                        hr = captureGraphBuilder.FindInterface(PinCategory.Capture, MediaType.Audio, audioFilter, typeof(IAMStreamConfig).GUID, out o);

                    //  hr = captureGraphBuilder.FindInterface(PinCategory.Capture, MediaType.Audio, audioFilter, typeof(IAMStreamConfig).GUID, out o);
                    if (hr > 0)
                    {
                        IAMStreamConfig audioStreamConfig = (IAMStreamConfig)o;
                        setStreamConfigSetting(audioStreamConfig, "nChannels", nchannels);
                        setStreamConfigSetting(audioStreamConfig, "nSamplesPerSec", audioSamplingRate);
                        short bps = (short)getStreamConfigSetting(audioStreamConfig, "wBitsPerSample");
                        setStreamConfigSetting(audioStreamConfig, "wBitsPerSample", audioSamplingSize);
                    }
                }

            }


        }


        private void StartRecording()
        {
            try
            {
                if (previewing) StopPreview();
                // IBaseFilter sourceFilter = null;
                int hr = 0;
                SetPinParameters(false);
                if (videoFilter != null)
                {
                    //Create the file writer part of the graph. SetOutputFileName does this for us, and returns the mux and sink
                    label13.Visible = true;
                    label12.Visible = true;
                    label13.Text = FileName;

                    File.Delete(FileName);

                    hr = captureGraphBuilder.SetOutputFileName(MediaSubType.Avi, FileName, out mux, out sink);

                    DsError.ThrowExceptionForHR(hr);

                    //Connect the device and compressor to the mux to render the capture part of the graph
                    hr = captureGraphBuilder.RenderStream(PinCategory.Capture, MediaType.Interleaved, videoFilter, videoCodecFilter, mux);
                    if (hr < 0)
                    {
                        hr = captureGraphBuilder.RenderStream(PinCategory.Capture, MediaType.Video, videoFilter, videoCodecFilter, mux);
                        DsError.ThrowExceptionForHR(hr);
                    }

                    if (audioFilter != null)
                    {

                        hr = captureGraphBuilder.RenderStream(PinCategory.Capture, MediaType.Audio, audioFilter, audioCodecFilter, mux);
                        if (hr < 0) Marshal.ThrowExceptionForHR(hr);
                    }

                    //Render any preview pin of the device
                    hr = captureGraphBuilder.RenderStream(PinCategory.Preview, MediaType.Video, videoFilter, null, null);
                    DsError.ThrowExceptionForHR(hr);

                    SetupVideoWindow();// wrzu� preview na panel;
                    DirectShowLib.Utils.FilterGraphTools.SaveGraphFile(graphBuilder, "D:\\graph.grf");


                    this.mediaControl.Run();// start recording

                    if (this.mediaEventEx != null) Marshal.ReleaseComObject(this.mediaEventEx); this.mediaEventEx = null;
                    if (this.captureGraphBuilder != null) Marshal.ReleaseComObject(this.captureGraphBuilder); this.captureGraphBuilder = null;
                    if (this.videoFilter != null) Marshal.ReleaseComObject(this.videoFilter); this.videoFilter = null;

                    if (this.mux != null) Marshal.ReleaseComObject(mux); mux = null;
                    if (this.sink != null) Marshal.ReleaseComObject(sink); sink = null;
                    if (this.tuner != null) Marshal.ReleaseComObject(tuner); sink = null;
                    if (this.crossbar != null) Marshal.ReleaseComObject(crossbar); sink = null;
                    recording = true;
                    timestart = DateTime.Now.Ticks;

                    timer1.Enabled = true;
                    label14.Visible = false;
                }
            }
            catch
            {
                label14.Top = panelVideo.Top + ((panelVideo.Height - label14.Height) / 2);
                label14.Left = panelVideo.Left + ((panelVideo.Width - label14.Width) / 2);
                label14.Visible = true;
                label14.Text = "NO VIDEO !!!\r\nOR VIDEO PROPETERIES ARE BAD !!!\r\n\r\nCheck config and cables.";

            }
        }


        private void StartPreview()
        {
            try
            {   // IBaseFilter sourceFilter = null;
                label14.Top = panelVideo.Top + ((panelVideo.Height - label14.Height) / 2);
                label14.Left = panelVideo.Left + ((panelVideo.Width - label14.Width) / 2);
                label14.Visible = true;
                label14.Text = "Please Wait.\r\nStarting  ...";
                if (recording) return;
                int hr = 0;

                SetPinParameters(true);
                if (videoFilter != null)
                {


                    hr = captureGraphBuilder.RenderStream(PinCategory.Preview, MediaType.Interleaved, videoFilter, null, null);
                    if (hr < 0)
                        captureGraphBuilder.RenderStream(PinCategory.Preview, MediaType.Video, videoFilter, null, null);


                    SetupVideoWindow();// wrzu� preview na panel;
                    this.mediaControl.Run();// start preview
                    previewing = true;
                    label14.Visible = false; ;


                }
            }
            catch
            {
                label14.Top = panelVideo.Top + ((panelVideo.Height - label14.Height) / 2);
                label14.Left = panelVideo.Left + ((panelVideo.Width - label14.Width) / 2);
                label14.Visible = true;
                label14.Text = "NO VIDEO !!!\r\nOR VIDEO PROPETERIES ARE BAD !!!\r\n\r\nCheck config and cables.";
            }
        }

        private void StopRecording()
        {
            if (recording)
            {

                if (mediaControl != null)
                    mediaControl.Stop();

                CloseInterfaces();

                previewing = false;
                recording = false;
                StartPreview();
            }
        }

        private void StopPreview()
        {
            if (previewing && !recording)
            {

                if (mediaControl != null)
                    mediaControl.Stop();

                CloseInterfaces();

                previewing = false;

            }
        }

        private void setPanelVideoSize(Size size)
        {

            panelVideo.Left = panelVideo.Top;
            panel2.Width = 320;
            int xofs = Width - ClientSize.Width;
            int yofs = Height - ClientSize.Height;
            panelVideo.Visible = true;
            panel2.Visible = true;
            panelCFG.Visible = false;
            panelVideo.Width = size.Width;
            panelVideo.Height = size.Height;

            this.Width = (2 * panelVideo.Left) + panelVideo.Width;
            panel2.Top = (2 * panelVideo.Top) + panelVideo.Height;
            if (this.ClientSize.Width < panel2.Width + (2 * panel2.Left)) this.Width = panel2.Width + (2 * panel2.Left) + xofs;


            this.Height = panel2.Top + panel2.Height + yofs + panelVideo.Top;
            if ((2 * panelVideo.Left) + panelVideo.Width < this.ClientSize.Width)
                panelVideo.Left = (ClientSize.Width - panelVideo.Width) / 2;

            panel2.Width = this.ClientSize.Width - (panel2.Left * 2);

            if (label14.Visible)
            {
                label14.Top = panelVideo.Top + ((panelVideo.Height - label14.Height) / 2);
                label14.Left = panelVideo.Left + ((panelVideo.Width - label14.Width) / 2);
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Width = this.ClientSize.Width;
            panel1.Height = this.ClientSize.Height;
           /* GetVidDevices();
            GetAudDevices();
            GetAudCodecs();
            GetVidCodecs();*/
            /* SamplingRateBox.SelectedIndex = 0;
             SamplingSizeBox.SelectedIndex = 0;
             VideoSizeBox.SelectedIndex = 2;
             FrameRateBox.SelectedIndex = 0;
             VideoDevicesBox.SelectedIndex = 1;*/
            LOAD();
            //load cfg data

            setPanelVideoSize(getVidSize(cfg.videoSize));
            StartPreview();
            // label13_Click(null, null);
            //VideoSourceBox

            //label14_Click(null, null);
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (recording) StopRecording(); else StartRecording();
            Font f = new Font(REC.Font.Name, REC.Font.Size, recording ? FontStyle.Bold : FontStyle.Regular);
            REC.Font = f;


        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (recording || previewing)
            {

                if (mediaControl != null)
                    mediaControl.Stop();
                recording = false; previewing = false;
            }
            CloseInterfaces();
            GC.Collect();
            SAVE();

        }


        [DllImport("olepro32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
        private static extern int OleCreatePropertyFrame(
            IntPtr hwndOwner, int x, int y,
            string lpszCaption, int cObjects,
            [In, MarshalAs(UnmanagedType.Interface)] ref object ppUnk,
            int cPages, IntPtr pPageClsID, int lcid, int dwReserved, IntPtr pvReserved);


        protected void ShowIfSupported(object o)
        {
            ISpecifyPropertyPages specifyPropertyPages = null;
            DsCAUUID cauuid = new DsCAUUID();


            // Determine if the object supports the interface
            // and has at least 1 property page
            try
            {
                specifyPropertyPages = o as ISpecifyPropertyPages;
                if (specifyPropertyPages != null)
                {


                    int hr = specifyPropertyPages.GetPages(out cauuid);
                    if ((hr != 0) || (cauuid.cElems <= 0))
                    {


                    }

                    else
                    {
                        hr = OleCreatePropertyFrame(Handle, 30, 30, null, 1,
                    ref o, cauuid.cElems, cauuid.pElems, 0, 0, IntPtr.Zero);
                    }


                }
            }
            finally
            {
                if (cauuid.pElems != IntPtr.Zero)
                    Marshal.FreeCoTaskMem(cauuid.pElems);
            }
        }



        private void button2_Click(object sender, EventArgs e)// VIDEO CODEC CONFIG
        {
            int idx = VideoCodecsBox.SelectedIndex;
            if (idx > 0)
            {
                try
                {
                    if (videoCodecFilter == null) videoCodecFilter = FindVideoCompresor(idx);

                    DirectShowLib.Utils.FilterGraphTools.ShowFilterPropertyPage(videoCodecFilter, Handle);
                    IAMVfwCompressDialogs compressDialog = videoCodecFilter as IAMVfwCompressDialogs;
                    int hr = compressDialog.ShowDialog(VfwCompressDialogs.Config, Handle);
                    //  if (hr != 0)
                    {

                    }
                }
                catch { }
            }


        }

        private void button3_Click(object sender, EventArgs e)// AUDIO CODEC CONFIG
        {
            int idx = AudioCodecBox.SelectedIndex;
            if (idx > 0)
            {
                try
                {
                    if (audioCodecFilter == null) audioCodecFilter = FindAudioCompresor(idx);
                    DirectShowLib.Utils.FilterGraphTools.ShowFilterPropertyPage(audioCodecFilter, Handle);
                    IAMVfwCompressDialogs compressDialog = videoCodecFilter as IAMVfwCompressDialogs;
                    int hr = compressDialog.ShowDialog(VfwCompressDialogs.Config, Handle);

                }
                catch { }
            }


        }


        private void button4_Click(object sender, EventArgs e)
        {
            int idx = AudioDevicesBox.SelectedIndex;
            if (idx > 0)
            {
                try
                {
                    DirectShowLib.Utils.FilterGraphTools.ShowFilterPropertyPage(FindAudioDevice(idx), Handle);
                }
                catch { }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int idx = VideoDevicesBox.SelectedIndex;
            if (idx > 0)
            {
                try
                {
                    DirectShowLib.Utils.FilterGraphTools.ShowFilterPropertyPage(FindCaptureDevice(idx), this.Handle);

                }
                catch { }
            }
        }





        private void Config_Click(object sender, EventArgs e)
        {
            int xofs = Width - ClientSize.Width;
            int yofs = Height - ClientSize.Height;

            if (recording) return;

            //panelCFG.Width = 533;
            //panelCFG.Height = 310;
            StopPreview(); CloseInterfaces();
            panelVideo.Visible = false;
            panel2.Visible = false;
            panelCFG.Top = 5;
            panelCFG.Left = 5;
            panelCFG.Visible = true;

            Width = panelCFG.Width + xofs + 10;
            Height = panelCFG.Height + yofs + 10;


            GetVidDevices();
            GetAudDevices();
            GetAudCodecs();
            GetVidCodecs();


            VideoDevicesBox.SelectedIndex = -1;
            for (int i = 0; i < VideoDevicesBox.Items.Count; i++)
                if (VideoDevicesBox.Items[i].ToString() == cfg.videoDevice) VideoDevicesBox.SelectedIndex = i;

            VideoCodecsBox.SelectedIndex = -1;
            for (int i = 0; i < VideoCodecsBox.Items.Count; i++)
                if (VideoCodecsBox.Items[i].ToString() == cfg.videoCodec) VideoCodecsBox.SelectedIndex = i;

            VideoSizeBox.SelectedIndex = -1;
            for (int i = 0; i < VideoSizeBox.Items.Count; i++)
                if (VideoSizeBox.Items[i].ToString() == cfg.videoSize) VideoSizeBox.SelectedIndex = i;

            FrameRateBox.SelectedIndex = -1;
            for (int i = 0; i < FrameRateBox.Items.Count; i++)
                if (FrameRateBox.Items[i].ToString() == cfg.videoFrameRate) FrameRateBox.SelectedIndex = i;

            //GetSources(null, null);

            if (tuner != null)
            {
                int channel;
                int.TryParse(cfg.videoChannel, out channel);
                AMTunerSubChannel videoSubCh, audioSubCh;
                videoSubCh = AMTunerSubChannel.Default; audioSubCh = AMTunerSubChannel.Default;
                tuner.put_Channel(channel, videoSubCh, audioSubCh);
                cfg.videoChannel = channel.ToString();
            }

            if (crossbar != null)
            {
                if (VideoSources_.Count > 0)
                {
                    for (int i = 0; i < videoSources.Count; i++)
                    {
                        if (videoSources[i].Name == cfg.videoCrossbarInput) videoSources[i].Enabled = true;
                    }
                }

            }

            AudioDevicesBox.SelectedIndex = -1;
            for (int i = 0; i < AudioDevicesBox.Items.Count; i++)
                if (AudioDevicesBox.Items[i].ToString() == cfg.audioDevice) AudioDevicesBox.SelectedIndex = i;

            AudioSourceBox.SelectedIndex = -1;
            for (int i = 0; i < AudioSourceBox.Items.Count; i++)
                if (AudioSourceBox.Items[i].ToString() == cfg.audioInputSource) AudioSourceBox.SelectedIndex = i;

            AudioCodecBox.SelectedIndex = -1;
            for (int i = 0; i < AudioCodecBox.Items.Count; i++)
                if (AudioCodecBox.Items[i].ToString() == cfg.audioCodec) AudioCodecBox.SelectedIndex = i;

            if (cfg.audioChanels.ToLower()[0] == 's') stereo.Checked = true; else stereo.Checked = false;
            mono.Checked = !stereo.Checked;

            SamplingRateBox.SelectedIndex = -1;
            for (int i = 0; i < SamplingRateBox.Items.Count; i++)
                if (SamplingRateBox.Items[i].ToString() == cfg.audioSamplingRate) SamplingRateBox.SelectedIndex = i;

            SamplingSizeBox.SelectedIndex = -1;
            for (int i = 0; i < SamplingSizeBox.Items.Count; i++)
                if (SamplingSizeBox.Items[i].ToString() == cfg.audioSamplingSize) SamplingSizeBox.SelectedIndex = i;

            if (cfg.audioCapture.ToLower()[0] == 't') AudioCheckBox.Checked = true; else AudioCheckBox.Checked = false;






        }

        public Size getVidSize(string selection)
        {
            try
            {
                int x, y;

                string x1 = selection.Substring(0, selection.IndexOf('x'));
                string y1 = selection.Substring(selection.IndexOf('x') + 1, selection.Length - selection.IndexOf('x') - 1);
                int.TryParse(x1, out x);
                int.TryParse(y1, out y);
                return new Size(x, y);
            }
            catch
            { return new Size(0, 0); }

        }


        private void Back_Click(object sender, EventArgs e)
        {
            if (VideoDevicesBox.SelectedIndex > -1) cfg.videoDevice = VideoDevicesBox.Items[VideoDevicesBox.SelectedIndex].ToString(); else cfg.videoDevice = null;
            if (VideoCodecsBox.SelectedIndex > -1) cfg.videoCodec = VideoCodecsBox.Items[VideoCodecsBox.SelectedIndex].ToString(); else cfg.videoCodec = null;
            if (VideoSizeBox.SelectedIndex > -1) cfg.videoSize = VideoSizeBox.Items[VideoSizeBox.SelectedIndex].ToString(); else cfg.videoSize = "640x480";

            if (FrameRateBox.SelectedIndex > -1) cfg.videoFrameRate = FrameRateBox.Items[FrameRateBox.SelectedIndex].ToString(); else cfg.videoFrameRate = "25";


            if (tuner != null)
            {
                int channel;
                AMTunerSubChannel videoSubCh, audioSubCh;
                videoSubCh = AMTunerSubChannel.Default; audioSubCh = AMTunerSubChannel.Default;
                tuner.get_Channel(out channel, out videoSubCh, out audioSubCh);
                cfg.videoChannel = channel.ToString();
            }

            if (crossbar != null)
            {
                if (VideoSources_.Count > 0)
                {
                    for (int i = 0; i < videoSources.Count; i++)
                    {
                        if (videoSources[i].Enabled) cfg.videoCrossbarInput = videoSources[i].Name;
                    }
                }

            }

            if (AudioDevicesBox.SelectedIndex > -1) cfg.audioDevice = AudioDevicesBox.Items[AudioDevicesBox.SelectedIndex].ToString(); else cfg.audioDevice = null;
            if (AudioSourceBox.SelectedIndex > -1) cfg.audioInputSource = AudioSourceBox.Items[AudioSourceBox.SelectedIndex].ToString(); else cfg.audioInputSource = null;
            if (AudioCodecBox.SelectedIndex > -1) cfg.audioCodec = AudioCodecBox.Items[AudioCodecBox.SelectedIndex].ToString(); else cfg.audioCodec = null;
            if (stereo.Checked) cfg.audioChanels = "stereo"; else cfg.audioChanels = "mono";
            if (SamplingRateBox.SelectedIndex > -1) cfg.audioSamplingRate = SamplingRateBox.Items[SamplingRateBox.SelectedIndex].ToString(); else cfg.audioSamplingRate = "22050";

            if (SamplingSizeBox.SelectedIndex > -1) cfg.audioSamplingSize = SamplingSizeBox.Items[SamplingSizeBox.SelectedIndex].ToString(); else cfg.audioSamplingSize = "16";

            if (AudioCheckBox.Checked) cfg.audioCapture = "true"; else cfg.audioCapture = "false";
            SAVE();

            CloseInterfaces();
            int xofs = Width - ClientSize.Width;
            int yofs = Height - ClientSize.Height;
            panelVideo.Visible = true;
            panel2.Visible = true;
            panelCFG.Visible = false;


            this.Width = (2 * panelVideo.Left) + panelVideo.Width;
            panel2.Top = (2 * panelVideo.Top) + panelVideo.Height;

            this.Height = panel2.Top + panel2.Height + yofs + panelVideo.Top;
            StartPreview();
        }

        #region DragNdrop
        int sx, sy, lx, ly;
        bool dwn = false;
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (sender is Form || sender is Panel)
            {

                sx = MousePosition.X;
                sy = MousePosition.Y;
                lx = Left;
                ly = Top;
                dwn = true;
            }
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (dwn)
            {
                int dx = sx - MousePosition.X;
                int dy = sy - MousePosition.Y;

                this.Left = lx - dx;
                this.Top = ly - dy;
            }

        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            dwn = false;
        }

        private void Form1_MouseLeave(object sender, EventArgs e)
        {
            dwn = false;
        }
        #endregion




        private void REC_Click(object sender, EventArgs e)
        {


            if (recording)
            {
                label14.Top = panelVideo.Top + ((panelVideo.Height - label14.Height) / 2);
                label14.Left = panelVideo.Left + ((panelVideo.Width - label14.Width) / 2);
                label14.Visible = true;
                label14.Text = "Please Wait.\r\nStoppnig  ...";
                Refresh();

                StopRecording();
                label14.Visible = false ;
            }
            else
            {
                string drive = "-";
                string file = "-";
                string ext = "GB";
                long delta = 7777777777;
                try
                {
                    DriveInfo di = new DriveInfo(FileName.Substring(0, 3));
                    delta = di.AvailableFreeSpace;

                }
                catch { }
                if (delta < 2147483648)
                {

                    label12.Visible = true;
                    label12.Text = "No free disc space !!!!";
                    label12.ForeColor = Color.Red;
                    timer1.Enabled = false;
                    return;
                }
                label14.Top = panelVideo.Top + ((panelVideo.Height - label14.Height) / 2);
                label14.Left = panelVideo.Left + ((panelVideo.Width - label14.Width) / 2);
                label14.Visible = true;
                label14.Text = "Please Wait.\r\n Starting ...";

                Refresh();
                
                StartRecording();
                //label14.Visible = false;
            }
            if (recording)
            {
                REC.Font = new Font(REC.Font.Name, REC.Font.Size, FontStyle.Bold);
                REC.BackColor = Color.Red;
                REC.Text = "Stop";
            }
            else
            {
                label13.Visible = false;
                label12.Visible = false;
                REC.Font = new Font(REC.Font.Name, REC.Font.Size, FontStyle.Regular);
                REC.BackColor = Color.Silver;
                REC.Text = "Rec";
                timer1.Enabled = false;
            }


        }



        private void Crossbar_Click(object sender, EventArgs e)
        {
            if (crossbar != null)
            {
                DirectShowLib.Utils.FilterGraphTools.ShowFilterPropertyPage(crossbar, this.Handle);
            }

        }

        private void Tuner__Click(object sender, EventArgs e)
        {
            if (tuner != null)
            {
                DirectShowLib.Utils.FilterGraphTools.ShowFilterPropertyPage((IBaseFilter)tuner, this.Handle);
            }
        }

        private void buttonOne_Click(object sender, EventArgs e)
        {
            Size size = getVidSize(cfg.videoSize);
            int divider = 1;
            if (sender is ToolStripMenuItem)
            {
                string name = ((ToolStripMenuItem)sender).Name;
                if (name == "Half") divider = 2;
                if (name == "Quarter") divider = 4;
                if (name == "One") divider = 1;
                if (name == "MAX") divider = 0;
                MAX.Checked = false;
                One.Checked = false;
                Quarter.Checked = false;
                Half.Checked = false;

                ((ToolStripMenuItem)sender).Checked = true;

            }
            if (divider != 0)
            {
                size.Width = size.Width / divider;
                size.Height = size.Height / divider;
            }
            else
            {
                Width = Screen.PrimaryScreen.WorkingArea.Width;
                Height = Screen.PrimaryScreen.WorkingArea.Height;

                int w, h, x, y;
                double scale;
                scale = 1.0 * size.Width / size.Height;
                //working area
                this.Refresh();
                y = this.ClientSize.Height - ((panelVideo.Top * 3) + panel2.Height);
                x = this.ClientSize.Width - ((panelVideo.Left * 2));
                h = y;
                w = (int)Math.Round(h * scale);
                if (w > x)
                {
                    w = x;
                    h = (int)Math.Round(w / scale);
                }
                if (w > x) w = x;
                if (h > y) h = y;
                size.Width = w;
                size.Height = h;
                // MessageBox.Show(w + " " + h+"\r\n"+Width+"x"+Height);

            }
            setPanelVideoSize(size);


            if (recording || previewing)
            {
                SetupVideoWindow();
            }
        }


        private void label15_Click(object sender, EventArgs e)
        {
            if (!recording) Close();
        }

        private void Menu_Click(object sender, EventArgs e)
        {
            contextMenuStrip1.Show();
            this.Refresh();

            contextMenuStrip1.Top = buttonMenu.Top + panel2.Top - contextMenuStrip1.Height;
            contextMenuStrip1.Left = buttonMenu.Left + panel2.Left;
            if (recording)
            {
                configureToolStripMenuItem.Enabled = false;
                exitToolStripMenuItem.Enabled = false;
            }
            else
            {
                configureToolStripMenuItem.Enabled = true;
                exitToolStripMenuItem.Enabled = true;
            }

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void minimizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        int some = 11;
        private void timer1_Tick(object sender, EventArgs e)
        {
            some++;
            long current = DateTime.Now.Ticks;

            long delta = current - timestart;

            DateTime dt = new DateTime(delta);

            int s = dt.Second;
            int m = dt.Minute;
            int h = dt.Hour;

            label8.Text = (h < 10 ? "0" : "") + h.ToString() + ":" + (m < 10 ? "0" : "") + m.ToString() + ":" + (s < 10 ? "0" : "") + s.ToString();
            if (some > 10)
            {
                some = 0;

                if (FileName.Length > 3)
                {
                    string drive = "-";
                    string file = "-";
                    string ext = "GB";
                    double de = 7777777777;
                    try
                    {

                        FileInfo fi = new FileInfo(FileName);
                        double li2 = fi.Length;
                        DriveInfo di = new DriveInfo(FileName.Substring(0, 3));
                        double li = di.AvailableFreeSpace;
                        if (li > 0 && li2 > 0) de = li - li2;
                        ext = "B";
                        if (li > 1024) { li = li / 1024.0; li2 = li2 / 1024.0; ext = "kB"; }
                        if (li > 1024) { li = li / 1024.0; li2 = li2 / 1024.0; ext = "MB"; }
                        if (li > 1024) { li = li / 1024.0; li2 = li2 / 1024.0; ext = "GB"; }

                        drive = Math.Round(li, 2).ToString();
                        file = Math.Round(li2, 2).ToString();


                    }
                    catch { }

                    label12.Text = file + " from " + drive + " " + ext;
                    if (de < 2147483648)
                    {
                        StopRecording();
                        label12.Visible = true;
                        label12.Text = "No free disc space !!!!";
                        label12.ForeColor = Color.Red;
                        timer1.Enabled = false;
                    }



                }
            }


        }

        private void VideoCodecsBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (videoCodecFilter != null)
            {
                Marshal.ReleaseComObject(videoCodecFilter);
                videoCodecFilter = null;
                videoCodecFilter = FindVideoCompresor(VideoCodecsBox.SelectedIndex);
            }
        }

        private void AudioCodecBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (audioCodecFilter != null)
            {
                Marshal.ReleaseComObject(audioCodecFilter);
                audioCodecFilter = null;
                audioCodecFilter = FindAudioCompresor(AudioCodecBox.SelectedIndex);
            }

        }








    }
}