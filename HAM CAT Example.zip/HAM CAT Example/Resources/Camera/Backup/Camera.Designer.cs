namespace Camera
{
    partial class Camera
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelVideo = new System.Windows.Forms.Panel();
            this.REC = new System.Windows.Forms.Button();
            this.VideoDevicesBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.AudioDevicesBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.AudioCodecBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.VideoCodecsBox = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.mono = new System.Windows.Forms.RadioButton();
            this.stereo = new System.Windows.Forms.RadioButton();
            this.SamplingRateBox = new System.Windows.Forms.ComboBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SamplingSizeBox = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.VideoSizeBox = new System.Windows.Forms.ComboBox();
            this.FrameRateBox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.AudioCheckBox = new System.Windows.Forms.CheckBox();
            this.Crossbar = new System.Windows.Forms.Button();
            this.AudioSourceBox = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panelCFG = new System.Windows.Forms.Panel();
            this.buttonBack = new System.Windows.Forms.Button();
            this.Tuner_ = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonMenu = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.sizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MAX = new System.Windows.Forms.ToolStripMenuItem();
            this.One = new System.Windows.Forms.ToolStripMenuItem();
            this.Half = new System.Windows.Forms.ToolStripMenuItem();
            this.Quarter = new System.Windows.Forms.ToolStripMenuItem();
            this.configureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.minimizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panelCFG.SuspendLayout();
            this.panel2.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelVideo
            // 
            this.panelVideo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelVideo.Location = new System.Drawing.Point(5, 5);
            this.panelVideo.Name = "panelVideo";
            this.panelVideo.Size = new System.Drawing.Size(320, 240);
            this.panelVideo.TabIndex = 0;
            this.panelVideo.MouseLeave += new System.EventHandler(this.Form1_MouseLeave);
            this.panelVideo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.panelVideo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.panelVideo.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            // 
            // REC
            // 
            this.REC.BackColor = System.Drawing.Color.Silver;
            this.REC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.REC.Location = new System.Drawing.Point(6, 3);
            this.REC.Name = "REC";
            this.REC.Size = new System.Drawing.Size(60, 25);
            this.REC.TabIndex = 1;
            this.REC.Text = "Rec.";
            this.REC.UseVisualStyleBackColor = false;
            this.REC.Click += new System.EventHandler(this.REC_Click);
            // 
            // VideoDevicesBox
            // 
            this.VideoDevicesBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.VideoDevicesBox.FormattingEnabled = true;
            this.VideoDevicesBox.Location = new System.Drawing.Point(5, 19);
            this.VideoDevicesBox.Name = "VideoDevicesBox";
            this.VideoDevicesBox.Size = new System.Drawing.Size(187, 21);
            this.VideoDevicesBox.TabIndex = 2;
            this.VideoDevicesBox.SelectedIndexChanged += new System.EventHandler(this.GetSources);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Video Device";
            // 
            // AudioDevicesBox
            // 
            this.AudioDevicesBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AudioDevicesBox.FormattingEnabled = true;
            this.AudioDevicesBox.Location = new System.Drawing.Point(212, 19);
            this.AudioDevicesBox.Name = "AudioDevicesBox";
            this.AudioDevicesBox.Size = new System.Drawing.Size(184, 21);
            this.AudioDevicesBox.TabIndex = 4;
            this.AudioDevicesBox.SelectedIndexChanged += new System.EventHandler(this.GetSources);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(209, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Audio Device";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(213, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Audio Codec";
            // 
            // AudioCodecBox
            // 
            this.AudioCodecBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AudioCodecBox.FormattingEnabled = true;
            this.AudioCodecBox.Location = new System.Drawing.Point(212, 172);
            this.AudioCodecBox.Name = "AudioCodecBox";
            this.AudioCodecBox.Size = new System.Drawing.Size(184, 21);
            this.AudioCodecBox.TabIndex = 6;
            this.AudioCodecBox.SelectedIndexChanged += new System.EventHandler(this.AudioCodecBox_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Video Codec";
            // 
            // VideoCodecsBox
            // 
            this.VideoCodecsBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.VideoCodecsBox.FormattingEnabled = true;
            this.VideoCodecsBox.Location = new System.Drawing.Point(8, 156);
            this.VideoCodecsBox.Name = "VideoCodecsBox";
            this.VideoCodecsBox.Size = new System.Drawing.Size(187, 21);
            this.VideoCodecsBox.TabIndex = 8;
            this.VideoCodecsBox.SelectedIndexChanged += new System.EventHandler(this.VideoCodecsBox_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(153, 140);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(42, 21);
            this.button2.TabIndex = 10;
            this.button2.Text = "Cfg.";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(354, 155);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(42, 21);
            this.button3.TabIndex = 11;
            this.button3.Text = "Cfg";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // mono
            // 
            this.mono.AutoSize = true;
            this.mono.Checked = true;
            this.mono.Location = new System.Drawing.Point(276, 80);
            this.mono.Name = "mono";
            this.mono.Size = new System.Drawing.Size(52, 17);
            this.mono.TabIndex = 13;
            this.mono.TabStop = true;
            this.mono.Text = "Mono";
            this.mono.UseVisualStyleBackColor = true;
            // 
            // stereo
            // 
            this.stereo.AutoSize = true;
            this.stereo.Location = new System.Drawing.Point(340, 80);
            this.stereo.Name = "stereo";
            this.stereo.Size = new System.Drawing.Size(56, 17);
            this.stereo.TabIndex = 14;
            this.stereo.Text = "Stereo";
            this.stereo.UseVisualStyleBackColor = true;
            // 
            // SamplingRateBox
            // 
            this.SamplingRateBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SamplingRateBox.FormattingEnabled = true;
            this.SamplingRateBox.Items.AddRange(new object[] {
            "8000 Hz",
            "11025 Hz",
            "22050 Hz",
            "44100 Hz"});
            this.SamplingRateBox.Location = new System.Drawing.Point(296, 97);
            this.SamplingRateBox.Name = "SamplingRateBox";
            this.SamplingRateBox.Size = new System.Drawing.Size(102, 21);
            this.SamplingRateBox.TabIndex = 15;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(354, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(42, 21);
            this.button4.TabIndex = 16;
            this.button4.Text = "Cfg";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(213, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Sampling rate :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(214, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Sampling Size:";
            // 
            // SamplingSizeBox
            // 
            this.SamplingSizeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SamplingSizeBox.FormattingEnabled = true;
            this.SamplingSizeBox.Items.AddRange(new object[] {
            "8 bit",
            "16 bit"});
            this.SamplingSizeBox.Location = new System.Drawing.Point(296, 124);
            this.SamplingSizeBox.Name = "SamplingSizeBox";
            this.SamplingSizeBox.Size = new System.Drawing.Size(102, 21);
            this.SamplingSizeBox.TabIndex = 18;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(150, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(42, 21);
            this.button5.TabIndex = 20;
            this.button5.Text = "Cfg.";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // VideoSizeBox
            // 
            this.VideoSizeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.VideoSizeBox.FormattingEnabled = true;
            this.VideoSizeBox.Items.AddRange(new object[] {
            "160x120",
            "320x240",
            "352x288",
            "640x480",
            "704x576",
            "720x576",
            "764x576"});
            this.VideoSizeBox.Location = new System.Drawing.Point(83, 82);
            this.VideoSizeBox.Name = "VideoSizeBox";
            this.VideoSizeBox.Size = new System.Drawing.Size(109, 21);
            this.VideoSizeBox.TabIndex = 21;
            // 
            // FrameRateBox
            // 
            this.FrameRateBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FrameRateBox.FormattingEnabled = true;
            this.FrameRateBox.Items.AddRange(new object[] {
            "5 (DVR)",
            "15 (econo)",
            "24 (film)",
            "25 (PAL)",
            "29.997 (NTSC)",
            "30 (~NTSC)"});
            this.FrameRateBox.Location = new System.Drawing.Point(83, 110);
            this.FrameRateBox.Name = "FrameRateBox";
            this.FrameRateBox.Size = new System.Drawing.Size(109, 21);
            this.FrameRateBox.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(213, 82);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Channels :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "Video size";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 113);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 13);
            this.label10.TabIndex = 26;
            this.label10.Text = "Framerate";
            // 
            // AudioCheckBox
            // 
            this.AudioCheckBox.AutoSize = true;
            this.AudioCheckBox.Location = new System.Drawing.Point(212, 199);
            this.AudioCheckBox.Name = "AudioCheckBox";
            this.AudioCheckBox.Size = new System.Drawing.Size(143, 17);
            this.AudioCheckBox.TabIndex = 27;
            this.AudioCheckBox.Text = "Capture audio with video";
            this.AudioCheckBox.UseVisualStyleBackColor = true;
            // 
            // Crossbar
            // 
            this.Crossbar.Location = new System.Drawing.Point(5, 45);
            this.Crossbar.Name = "Crossbar";
            this.Crossbar.Size = new System.Drawing.Size(79, 23);
            this.Crossbar.TabIndex = 28;
            this.Crossbar.Text = "Crossbar";
            this.Crossbar.UseVisualStyleBackColor = true;
            this.Crossbar.Visible = false;
            this.Crossbar.Click += new System.EventHandler(this.Crossbar_Click);
            // 
            // AudioSourceBox
            // 
            this.AudioSourceBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AudioSourceBox.FormattingEnabled = true;
            this.AudioSourceBox.Location = new System.Drawing.Point(212, 59);
            this.AudioSourceBox.Name = "AudioSourceBox";
            this.AudioSourceBox.Size = new System.Drawing.Size(184, 21);
            this.AudioSourceBox.TabIndex = 35;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(213, 43);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(98, 13);
            this.label11.TabIndex = 36;
            this.label11.Text = "Audio Input Source";
            // 
            // panelCFG
            // 
            this.panelCFG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.panelCFG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelCFG.Controls.Add(this.buttonBack);
            this.panelCFG.Controls.Add(this.Tuner_);
            this.panelCFG.Controls.Add(this.Crossbar);
            this.panelCFG.Controls.Add(this.VideoCodecsBox);
            this.panelCFG.Controls.Add(this.label11);
            this.panelCFG.Controls.Add(this.VideoDevicesBox);
            this.panelCFG.Controls.Add(this.AudioSourceBox);
            this.panelCFG.Controls.Add(this.AudioDevicesBox);
            this.panelCFG.Controls.Add(this.label2);
            this.panelCFG.Controls.Add(this.AudioCodecBox);
            this.panelCFG.Controls.Add(this.label1);
            this.panelCFG.Controls.Add(this.label3);
            this.panelCFG.Controls.Add(this.label4);
            this.panelCFG.Controls.Add(this.AudioCheckBox);
            this.panelCFG.Controls.Add(this.button2);
            this.panelCFG.Controls.Add(this.label10);
            this.panelCFG.Controls.Add(this.button3);
            this.panelCFG.Controls.Add(this.label9);
            this.panelCFG.Controls.Add(this.mono);
            this.panelCFG.Controls.Add(this.label7);
            this.panelCFG.Controls.Add(this.stereo);
            this.panelCFG.Controls.Add(this.FrameRateBox);
            this.panelCFG.Controls.Add(this.SamplingRateBox);
            this.panelCFG.Controls.Add(this.VideoSizeBox);
            this.panelCFG.Controls.Add(this.button4);
            this.panelCFG.Controls.Add(this.button5);
            this.panelCFG.Controls.Add(this.label5);
            this.panelCFG.Controls.Add(this.label6);
            this.panelCFG.Controls.Add(this.SamplingSizeBox);
            this.panelCFG.Location = new System.Drawing.Point(331, 5);
            this.panelCFG.Name = "panelCFG";
            this.panelCFG.Size = new System.Drawing.Size(407, 263);
            this.panelCFG.TabIndex = 38;
            this.panelCFG.MouseLeave += new System.EventHandler(this.Form1_MouseLeave);
            this.panelCFG.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.panelCFG.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.panelCFG.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            // 
            // buttonBack
            // 
            this.buttonBack.BackColor = System.Drawing.Color.Silver;
            this.buttonBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBack.Location = new System.Drawing.Point(13, 225);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(60, 25);
            this.buttonBack.TabIndex = 53;
            this.buttonBack.Text = "< Back";
            this.buttonBack.UseVisualStyleBackColor = false;
            this.buttonBack.Click += new System.EventHandler(this.Back_Click);
            // 
            // Tuner_
            // 
            this.Tuner_.Location = new System.Drawing.Point(113, 45);
            this.Tuner_.Name = "Tuner_";
            this.Tuner_.Size = new System.Drawing.Size(79, 23);
            this.Tuner_.TabIndex = 29;
            this.Tuner_.Text = "Tuner";
            this.Tuner_.UseVisualStyleBackColor = true;
            this.Tuner_.Visible = false;
            this.Tuner_.Click += new System.EventHandler(this.Tuner__Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.buttonMenu);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.REC);
            this.panel2.Location = new System.Drawing.Point(5, 261);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(320, 45);
            this.panel2.TabIndex = 41;
            this.panel2.MouseLeave += new System.EventHandler(this.Form1_MouseLeave);
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.panel2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.ForeColor = System.Drawing.Color.Silver;
            this.label13.Location = new System.Drawing.Point(6, 28);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 14);
            this.label13.TabIndex = 54;
            this.label13.Text = "filename";
            this.label13.Visible = false;
            // 
            // buttonMenu
            // 
            this.buttonMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonMenu.BackColor = System.Drawing.Color.Silver;
            this.buttonMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMenu.Location = new System.Drawing.Point(255, 3);
            this.buttonMenu.Name = "buttonMenu";
            this.buttonMenu.Size = new System.Drawing.Size(60, 25);
            this.buttonMenu.TabIndex = 52;
            this.buttonMenu.Text = "Menu >";
            this.buttonMenu.UseVisualStyleBackColor = false;
            this.buttonMenu.Click += new System.EventHandler(this.Menu_Click);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(84, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(149, 32);
            this.label8.TabIndex = 0;
            this.label8.Text = "00:00:00";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.MouseLeave += new System.EventHandler(this.Form1_MouseLeave);
            this.label8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.label8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.label8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sizeToolStripMenuItem,
            this.configureToolStripMenuItem,
            this.toolStripMenuItem1,
            this.minimizeToolStripMenuItem,
            this.toolStripMenuItem2,
            this.exitToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(128, 104);
            // 
            // sizeToolStripMenuItem
            // 
            this.sizeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MAX,
            this.One,
            this.Half,
            this.Quarter});
            this.sizeToolStripMenuItem.Name = "sizeToolStripMenuItem";
            this.sizeToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.sizeToolStripMenuItem.Text = "Size";
            // 
            // MAX
            // 
            this.MAX.Name = "MAX";
            this.MAX.Size = new System.Drawing.Size(100, 22);
            this.MAX.Text = "MAX";
            this.MAX.Click += new System.EventHandler(this.buttonOne_Click);
            // 
            // One
            // 
            this.One.Checked = true;
            this.One.CheckState = System.Windows.Forms.CheckState.Checked;
            this.One.Name = "One";
            this.One.Size = new System.Drawing.Size(100, 22);
            this.One.Text = "1:1";
            this.One.Click += new System.EventHandler(this.buttonOne_Click);
            // 
            // Half
            // 
            this.Half.Name = "Half";
            this.Half.Size = new System.Drawing.Size(100, 22);
            this.Half.Text = "1/2";
            this.Half.Click += new System.EventHandler(this.buttonOne_Click);
            // 
            // Quarter
            // 
            this.Quarter.Name = "Quarter";
            this.Quarter.Size = new System.Drawing.Size(100, 22);
            this.Quarter.Text = "1/4";
            this.Quarter.Click += new System.EventHandler(this.buttonOne_Click);
            // 
            // configureToolStripMenuItem
            // 
            this.configureToolStripMenuItem.Name = "configureToolStripMenuItem";
            this.configureToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.configureToolStripMenuItem.Text = "Configure";
            this.configureToolStripMenuItem.Click += new System.EventHandler(this.Config_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(124, 6);
            // 
            // minimizeToolStripMenuItem
            // 
            this.minimizeToolStripMenuItem.Name = "minimizeToolStripMenuItem";
            this.minimizeToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.minimizeToolStripMenuItem.Text = "Minimize";
            this.minimizeToolStripMenuItem.Click += new System.EventHandler(this.minimizeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(124, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(830, 325);
            this.panel1.TabIndex = 42;
            this.panel1.MouseLeave += new System.EventHandler(this.Form1_MouseLeave);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            // 
            // timer1
            // 
            this.timer1.Interval = 300;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.ForeColor = System.Drawing.Color.Silver;
            this.label12.Location = new System.Drawing.Point(207, 30);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(108, 14);
            this.label12.TabIndex = 55;
            this.label12.Text = "0,25 from 25 GB ";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label12.Visible = false;
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(380, 328);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(242, 69);
            this.label14.TabIndex = 0;
            this.label14.Text = "NO VIDEO !!!\r\nOR VIDEO PROPETERIES ARE BAD !!!";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Visible = false;
            // 
            // Camera
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(830, 403);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelVideo);
            this.Controls.Add(this.panelCFG);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Camera";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "TsoFt Cam Capturing System";
            this.TopMost = true;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelCFG.ResumeLayout(false);
            this.panelCFG.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelVideo;
        private System.Windows.Forms.Button REC;
        private System.Windows.Forms.ComboBox VideoDevicesBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox AudioDevicesBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox AudioCodecBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox VideoCodecsBox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RadioButton mono;
        private System.Windows.Forms.RadioButton stereo;
        private System.Windows.Forms.ComboBox SamplingRateBox;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox SamplingSizeBox;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox VideoSizeBox;
        private System.Windows.Forms.ComboBox FrameRateBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox AudioCheckBox;
        private System.Windows.Forms.Button Crossbar;
        private System.Windows.Forms.ComboBox AudioSourceBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panelCFG;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button Tuner_;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MAX;
        private System.Windows.Forms.ToolStripMenuItem One;
        private System.Windows.Forms.ToolStripMenuItem Half;
        private System.Windows.Forms.ToolStripMenuItem Quarter;
        private System.Windows.Forms.ToolStripMenuItem configureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem minimizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Button buttonMenu;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
    }
}

